<?php
	//Initialisasi nilai untuk nomor loket

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Aplikasi Suara Antrian</title>
<link rel="stylesheet" href="syle.css" />
<script type="text/javascript" src="jquery-1.7.2.js"></script>
<script type="text/javascript" >


</script>
</head>
<body >
		
		
		<div align="center" class="kontainer" style="color:white; text-shadow: 2px 2px 4px #000000;">Sistem Antrian Loket</div>
		<br><br><br><br>
		
		<div id="wrapper">
		
		<table align="center" border="10" cellpadding="15" bgcolor="#ie90ff" class="kontainer3" style="color:white; text-shadow: 2px 2px 4px #000000;">
		<tbody>
                          <tr>
                            <td><b><a href="pasien_lama.php"> Masuk Ke Loket Pasien Lama<br>(Loket 1 & Loket 2 || Loket 3)</a></b></td>
						</tr>
						  <tr>
							 <td><b><a href="pasien_baru.php"> Masuk Ke Loket Pasien Baru<br>(Loket 2 || Loket 3)</a></b></td>
                          </tr>
						   <tr>
							 <td><b><a href="pasien_proritas.php"> Masuk Ke Loket Pasien Proritas<br>(Loket 4)</a></b></td>
                          </tr>
                        </tbody>
						
						</table>
			</div>
						
						
						
					
</body>
</html>

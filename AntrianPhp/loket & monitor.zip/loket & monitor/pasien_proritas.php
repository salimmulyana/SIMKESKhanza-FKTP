<?php
include ('config.php');
	//Initialisasi nilai untuk nomor loket
	$loket="1";
	$loket2="2";
	$loket3="3";
	$loket4="4";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Aplikasi Suara Antrian</title>
<link rel="stylesheet" href="syle.css" />
<script type="text/javascript" src="jquery-1.7.2.js"></script>
<script type="text/javascript" >
$(document).ready(function(){
	$("#play").click(function(){
		document.getElementById('suarabel').play();		
	});
	
	
});

</script>
</head>
<body >
		<audio id="suarabel" src="Airport_Bell.wav"></audio>
		<audio id="suarabeel" src="Airport_Bell3.wav"></audio>
		<audio id="pasienlama" src="rekaman/Pasienpioritas.wav"></audio>
		<audio id="suarabelnomorurut" src="rekaman/no_urut.wav"  ></audio>  
		<audio id="l" src="rekaman/p.wav"  ></audio>  
		<audio id="suarabelsuarabelloket" src="rekaman/Diloket.wav"  ></audio> 
		<audio id="nol" src="rekaman/nol.wav"  ></audio> 
       
		<audio id="belas" src="rekaman/belas.wav"  ></audio> 
		<audio id="sebelas" src="rekaman/sebelas.wav"  ></audio> 
        <audio id="puluh" src="rekaman/puluh.wav"  ></audio> 
        <audio id="sepuluh" src="rekaman/sepuluh.wav"  ></audio> 
        <audio id="ratus" src="rekaman/ratus.wav"  ></audio> 
        <audio id="seratus" src="rekaman/seratus.wav"  ></audio>
        <audio id="suarabelloket1" src="rekaman/<?php echo $loket; ?>.wav"  ></audio> 
        <audio id="suarabelloket2" src="rekaman/<?php echo $loket2; ?>.wav"  ></audio> 
		<audio id="suarabelloket3" src="rekaman/<?php echo $loket3; ?>.wav"  ></audio> 
		<audio id="suarabelloket4" src="rekaman/<?php echo $loket4; ?>.wav"  ></audio> 
       
		<?php
			 $location_counter = "loket.txt";
			 $location_date = "date3.txt";
			 $itis = date ("d");
			 
			 // Hari baru?    
			$aday = join('', file($location_date));
			trim($aday);
		
			if("$aday"=="$itis"){
				//Cari hari ini
				$tcounter = join('', file($location_counter));
				trim($tcounter);
				$tcounter++;
				
				$fp = fopen($location_counter,"w");
				fputs($fp, $tcounter);
				fclose($fp);
			}else{
				//hari baru
				$fp = fopen($location_counter,"w");
				fputs($fp, 0);
				fclose($fp);
				$tcounter = join('', file($location_counter));
				trim($tcounter);
				$tcounter++;
				//tulis hari baru
				$fp = fopen($location_counter,"w");
				fputs($fp, $tcounter);
				fclose($fp);
				//tulis di date.txt
				$fp = fopen($location_date,"w");
				fputs($fp, $itis);
				fclose($fp);	
			}

			$panjang=strlen($tcounter);
			$antrian=$tcounter;
			
			for($i=0;$i<$panjang;$i++){
		?>
        		<audio id="suarabel<?php echo $i; ?>" src="rekaman/<?php echo substr($tcounter,$i,1); ?>.wav" ></audio>   		        
        <?php
			}
		?>
		
		<div align="center" class="kontainer" style="color:white; text-shadow: 2px 2px 4px #000000;">Sistem Antrian Loket</div>
		<br><br><br>
		<div class="kontainer2">
		<div id="wrapper2">
		
		<table align="center" border="10" cellpadding="15" bgcolor="transparent">
		<tbody>
                          <tr>
                            <td colspan='3' align='center'  scope="row"><b>LOKET 4</b></td>
						</tr>
						  <tr>
							 <td colspan='3' align='center'  scope="row">Pasien Proritas</td>
                          </tr>
                          <tr>
                            <td colspan='3' align='center' >
							<div class="kontainer">
							<div><a id="konter" href="pasien_proritas.php" ><?php echo 'P'.$antrian; ?></a>
							</div>
							</div>
							</td></tr>
                          <tr>
						  <td><div ><id="konter">  
							 <?php
								$query = "SELECT *FROM antrian_pr ";
								$result = mysqli_query($connection,$query);
								$data = array();
								while(($row = mysqli_fetch_array($result)) != null){
								$data[] = $row;
								}
								$count = count($data);
								echo "$count";
							 ?>
						  </a></div></td>
						   <td><div align="center"><input name="play" onclick="mulai();" type="image" src="icon.png" value="Panggil" /></div></td>
                            <td><div ><a id="konter" href="pasien_proritas.php">Next</a></div></td> </tr>
						   </tr>
                        </tbody></table>
						
						
						
					
</body>
</html>
<script type="text/javascript">
function mulai(){
	//MAINKAN SUARA BEL PADA SAAT AWAL
	document.getElementById('suarabel').pause();
	document.getElementById('suarabel').currentTime=0;
	document.getElementById('suarabel').play();
			
	//SET DELAY UNTUK MEMAINKAN REKAMAN NOMOR URUT		
	totalwaktu=document.getElementById('suarabel').duration*1200;	
	//MAINKAN SUARA Pasienlam
	setTimeout(function() {
			document.getElementById('pasienlama').pause();
			document.getElementById('pasienlama').currentTime=0;
			document.getElementById('pasienlama').play();
	}, totalwaktu);
	totalwaktu=totalwaktu+1500;
	
	
	
	//MAINKAN SUARA NOMOR URUT		
	setTimeout(function() {
			document.getElementById('suarabelnomorurut').pause();
			document.getElementById('suarabelnomorurut').currentTime=0;
			document.getElementById('suarabelnomorurut').play();
	}, totalwaktu);
	totalwaktu=totalwaktu+1000;
	
	//MAINKAN SUARA P		
	setTimeout(function() {
			document.getElementById('l').pause();
			document.getElementById('l').currentTime=0;
			document.getElementById('l').play();
	}, totalwaktu);
	totalwaktu=totalwaktu+1000;
	
	<?php
		//JIKA KURANG DARI 10 MAKA MAIKAN SUARA ANGKA1
		if($antrian<10){
	?>
			
			setTimeout(function() {
					document.getElementById('suarabel0').pause();
					document.getElementById('suarabel0').currentTime=0;
					document.getElementById('suarabel0').play();
				}, totalwaktu);
			
			totalwaktu=totalwaktu+1000;
	<?php		
		}elseif($antrian ==10){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
	?>  
				setTimeout(function() {
						document.getElementById('sepuluh').pause();
						document.getElementById('sepuluh').currentTime=0;
						document.getElementById('sepuluh').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
		<?php		
			}elseif($antrian ==11){
				//JIKA 11 MAKA MAIKAN SUARA SEBELAS
		?>  
				setTimeout(function() {
						document.getElementById('sebelas').pause();
						document.getElementById('sebelas').currentTime=0;
						document.getElementById('sebelas').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
		<?php		
			}elseif($antrian < 20){
				//JIKA 12-20 MAKA MAIKAN SUARA ANGKA2+"BELAS"
		?>  				
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('belas').pause();
						document.getElementById('belas').currentTime=0;
						document.getElementById('belas').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
		<?php		
			}elseif($antrian <= 99){				
				//JIKA PULUHAN MAKA MAINKAN SUARA ANGKA1+PULUH+AKNGKA2
		?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('puluh').pause();
						document.getElementById('puluh').currentTime=0;
						document.getElementById('puluh').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+900;
				
				<?php		
			}elseif($antrian ==100){
				//JIKA 100 MAKA MAIKAN SUARA RATUS 
		?>
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
		<?php
			}elseif($antrian <= 109){
				//JIKA 100 MAKA MAIKAN SUARA RATUS
		?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
					setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel2').pause();
						document.getElementById('suarabel2').currentTime=0;
						document.getElementById('suarabel2').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				
			
		<?php		
		}elseif($antrian ==110){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
	?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				
				<?php		
				}elseif($antrian ==111){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
				?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel2').pause();
						document.getElementById('suarabel2').currentTime=0;
						document.getElementById('suarabel2').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				
				<?php		
				}elseif($antrian > 111){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
				?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel2').pause();
						document.getElementById('suarabel2').currentTime=0;
						document.getElementById('suarabel2').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				
				<?php		
				}elseif($antrian ==120 or $antrian ==130 or $antrian ==140 or $antrian ==150 or $antrian ==160 or $antrian ==170 or $antrian ==180 or $antrian ==190){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
				?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				
				<?php		
				}elseif($antrian ==200 or $antrian ==300){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
				?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				
				<?php
			}elseif($antrian < 209){
				//JIKA 100 MAKA MAIKAN SUARA RATUS
		?>  
					setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel2').pause();
						document.getElementById('suarabel2').currentTime=0;
						document.getElementById('suarabel2').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
				<?php		
		}elseif($antrian ==210){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
	?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
					setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				
				<?php		
				}elseif($antrian ==211 ){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
				?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
					totalwaktu=totalwaktu+1000;
					setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel2').pause();
						document.getElementById('suarabel2').currentTime=0;
						document.getElementById('suarabel2').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				
				<?php		
				}elseif($antrian ==220 or $antrian ==230 or $antrian ==240 or $antrian ==250 or $antrian ==260 or $antrian ==270 or $antrian ==280 or $antrian ==290){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
				?>  
				setTimeout(function() {
						document.getElementById('suarabel0').pause();
						document.getElementById('suarabel0').currentTime=0;
						document.getElementById('suarabel0').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('nol').pause();
						document.getElementById('nol').currentTime=0;
						document.getElementById('nol').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
		<?php
			}else{
				//JIKA LEBIH DARI 100 
				//Karena aplikasi ini masih sederhana maka logina konversi hanya sampai 100
				//Selebihnya akan langsung disebutkan angkanya saja 
				//tanpa kata "RATUS", "PULUH", maupun "BELAS"
		?>
		
		<?php 
			for($i=0;$i<$panjang;$i++){
		?>
		
		totalwaktu=totalwaktu+1000;
		setTimeout(function() {
						document.getElementById('suarabel<?php echo $i; ?>').pause();
						document.getElementById('suarabel<?php echo $i; ?>').currentTime=0;
						document.getElementById('suarabel<?php echo $i; ?>').play();
					}, totalwaktu);
		<?php
			}
			}
		?>
		
		
		totalwaktu=totalwaktu+1000;
		setTimeout(function() {
						document.getElementById('suarabelsuarabelloket').pause();
						document.getElementById('suarabelsuarabelloket').currentTime=0;
						document.getElementById('suarabelsuarabelloket').play();
					}, totalwaktu);
		
		totalwaktu=totalwaktu+1000;
		setTimeout(function() {
						document.getElementById('suarabelloket<?php echo $loket4; ?>').pause();
						document.getElementById('suarabelloket<?php echo $loket4; ?>').currentTime=0;
						document.getElementById('suarabelloket<?php echo $loket4; ?>').play();
					}, totalwaktu);	
					totalwaktu=totalwaktu+1000;
		setTimeout(function() {
						document.getElementById('suarabeel').pause();
						document.getElementById('suarabeel').currentTime=0;
						document.getElementById('suarabeel').play();
					}, totalwaktu);			
}



</script>